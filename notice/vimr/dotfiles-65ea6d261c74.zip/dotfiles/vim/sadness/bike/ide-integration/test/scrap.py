class MyClass:
    def myMethod(self, foo):
        pass

a = MyClass()

a.myMethod()


class AnotherClass:
    def myMethod(self,foo):
        pass

def testFunction():
    print "hello"


print "hello"

