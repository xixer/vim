from scrap import MyClass, testFunction

b = MyClass()

b.myMethod()


c = abcde()

c.myMethod()


d = defgh()

d.myMethod()


e = MyClass()

e.myMethod()
