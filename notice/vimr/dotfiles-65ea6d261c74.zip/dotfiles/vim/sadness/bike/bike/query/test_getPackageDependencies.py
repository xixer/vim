#!/usr/bin/env python
import setpath
import unittest
import os
from bike import testdata
from bike.testutils import *

class TestGetPackageDependencies(BRMTestCase):
    def test_foo(self):
        assert 0
