TheClass = """
class TheClass:
    def theMethod(self):
        pass
    def differentMethod(self):
        pass

class DifferentClass:
    def theMethod(self):
        pass
"""


Function = """
def theFunction():
    pass
"""
