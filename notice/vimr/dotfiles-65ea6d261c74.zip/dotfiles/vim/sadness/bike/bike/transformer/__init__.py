"""
Package containing modules which transform the internal
representation of the sourcecode.
"""
