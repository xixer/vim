#!/usr/bin/env python

# fileInPackage is the filename of a file in the package hierarchy
def getPackageDependencies(fileInPackage):
    

