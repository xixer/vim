#!/usr/bin/env python
import setpath
import unittest
from testutils import*
import testdata
import sys

if __name__ == "__main__":
    unittest.main()
